package org.kde.taglib.ogg.vorbis;

import org.kde.taglib.AudioProperties;
import org.kde.taglib.FileRef;

public class Properties extends AudioProperties {
	public Properties(FileRef ref, long ptr) {
		super(ref, ptr);
	}
	
	public int getVorbisVersion()  { return getVorbisVersion(ptr); }
	public int getBitrateMaximum() { return getBitrateMaximum(ptr); }
	public int getBitrateNominal() { return getBitrateNominal(ptr); }
	public int getBitrateMinimum() { return getBitrateMinimum(ptr); }

	private static native int getVorbisVersion(long ptr);
	private static native int getBitrateMaximum(long ptr);
	private static native int getBitrateNominal(long ptr);
	private static native int getBitrateMinimum(long ptr);
}
