package org.kde.taglib.ogg.speex;

import org.kde.taglib.AudioProperties;
import org.kde.taglib.FileRef;

public class Properties extends AudioProperties {
	protected Properties(FileRef ref, long ptr) {
		super(ref, ptr);
	}

	public int getSpeexVersion() {
		return getSpeexVersion(ptr);
	}

	private static native int getSpeexVersion(long ptr);
}
