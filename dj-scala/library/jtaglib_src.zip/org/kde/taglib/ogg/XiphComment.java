package org.kde.taglib.ogg;

import java.util.Arrays;
import java.util.Iterator;
import java.util.Map;
import java.util.NoSuchElementException;

import org.kde.taglib.FileRef;
import org.kde.taglib.Tag;

public class XiphComment extends Tag {
	private class Field implements Map.Entry<String, String[]> {
		private final String   key; 
		private final String[] value;

		public Field(String key, String[] value) {
			this.key   = key;
			this.value = value;
		}
		
		@Override
		public String getKey() {
			return key;
		}

		@Override
		public String[] getValue() {
			return value;
		}

		@Override
		public String[] setValue(String[] value) {
			throw new UnsupportedOperationException();
		}
		
		@Override
		public String toString() {
			return String.format("%s: %s", key, Arrays.toString(value));
		}
	}
	
	private class FieldIterator
	implements Iterator<Map.Entry<String,String[]>> {
		private long it;
		private Field field = null;
		
		public FieldIterator() {
			it = begin(ptr);
			
			if (!isEnd(ptr, it)) {
				field = new Field(first(it), second(it));
			}
		}
		
		@Override
		public boolean hasNext() {
			return field != null;
		}

		@Override
		public Map.Entry<String,String[]> next() {
			Field reply = field;
			
			if (reply == null) {
				throw new NoSuchElementException();
			}

			XiphComment.next(it);
			
			if (isEnd(ptr, it)) {
				field = null;
			}
			else {
				field = new Field(first(it), second(it));
			}
			
			return reply;
		}

		@Override
		public void remove() {
			throw new UnsupportedOperationException();
		}

		@Override
		protected void finalize() throws Throwable {
			deleteIterator(it);
		}
	}
	
	private static native long     begin(long ptr);
	private static native boolean  isEnd(long ptr, long it);
	private static native void     deleteIterator(long it);
	private static native String   first(long it);
	private static native String[] second(long it);
	private static native void     next(long it);
	
	private class FieldIterable
	implements Iterable<Map.Entry<String,String[]>> {
		@Override
		public Iterator<Map.Entry<String,String[]>> iterator() {
			return new FieldIterator();
		}
	}
	
	private FieldIterable fields = new FieldIterable();
	
	protected XiphComment(FileRef ref, long ptr) {
		super(ref, ptr);
	}

	public Iterable<Map.Entry<String,String[]>> getFields() {
		return fields;
	}
	
	public long getFieldCount() { return getFieldCount(ptr); }
	public String getVendorID() { return getVendorID(ptr); }

	public String[] findField(String key) {
		return findField(ptr, key);
	}
	
	public void addField(String key, String value) {
		addField(ptr, key, value, true);
	}
	
	public void addField(String key, String value, boolean replace) {
		addField(ptr, key, value, replace);
	}
	
	public void removeField(String key) {
		removeField(ptr, key, null);
	}
	
	public void removeField(String key, String value)  {
		removeField(ptr, key, value);
	}
	
	public boolean contains(String key) { return contains(ptr, key); }

	private static native long     getFieldCount(long ptr);
	private static native String   getVendorID(long ptr);
	private static native String[] findField(long ptr, String key);
	private static native void     addField(long ptr, String key, String value, boolean replace);
	private static native void     removeField(long ptr, String key, String value);
	private static native boolean  contains(long ptr, String key);
}
