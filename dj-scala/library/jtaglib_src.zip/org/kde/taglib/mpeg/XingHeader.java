package org.kde.taglib.mpeg;


public class XingHeader {
	@SuppressWarnings("unused")
	private final Properties ref;
	private final long ptr;
	
	protected XingHeader(Properties ref, long ptr) {
		this.ref = ref;
		this.ptr = ptr;
	}

	public boolean isValid()        { return isValid(ptr); }
	public long    getTotalFrames() { return getTotalFrames(ptr); }
	public long    getTotalSize()   { return getTotalSize(ptr); }
	
	private static native boolean isValid(long ptr);
	private static native long    getTotalFrames(long ptr);
	private static native long    getTotalSize(long ptr);
}
