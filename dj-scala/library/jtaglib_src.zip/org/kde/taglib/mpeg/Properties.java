package org.kde.taglib.mpeg;

import org.kde.taglib.AudioProperties;
import org.kde.taglib.FileRef;

public class Properties extends AudioProperties {
	public static enum ChannelMode {
		Stereo,
		JointStereo,
		DualChannel,
		SingleChannel;
	}
	
	public static enum Version {
		Version1,
		Version2,
		Version2_5;
	}

	private XingHeader xingHeader = null; 

	protected Properties(FileRef ref, long ptr) {
		super(ref, ptr);
	}

	public int     getLayer()             { return getLayer(ptr); }
	public boolean getProtectionEnabled() { return getProtectionEnabled(ptr); }
	public boolean isCopyrighted()        { return isCopyrighted(ptr); }
	public boolean isOriginal()           { return isOriginal(ptr); }

	public XingHeader getXingHeader() {
		if (xingHeader == null) {
			long phdr = getXingHeader(ptr);
			
			if (phdr == 0) {
				return null;
			}
			
			xingHeader = new XingHeader(this, phdr);
		}
		
		return xingHeader;
	}

	public Version getVersion() {
		return Version.values()[getVersion(ptr)];
	}
	
	public ChannelMode getChannelMode() {
		return ChannelMode.values()[getChannelMode(ptr)];
	}
	
	private static native int     getLayer(long ptr);
	private static native boolean getProtectionEnabled(long ptr);
	private static native boolean isCopyrighted(long ptr);
	private static native boolean isOriginal(long ptr);
	private static native long    getXingHeader(long ptr);
	private static native int     getVersion(long ptr);
	private static native int     getChannelMode(long ptr);
}
