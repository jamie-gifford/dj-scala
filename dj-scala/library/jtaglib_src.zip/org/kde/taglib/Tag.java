package org.kde.taglib;

/**
 * TODO: wrap all of taglibs tag classes.
 * @author panzi
 *
 */
public class Tag {
	final protected long ptr;
	
	/** Because the Tag will be deleted when the FileRef
	 *  gets deleted we need this to keep the FileRef alive.
	 */
	@SuppressWarnings("unused")
	final private FileRef ref;

	protected Tag(FileRef ref, long ptr) {
		this.ref = ref;
		this.ptr = ptr;
	}

	private static native String getTitle  (long ptr);
	private static native String getArtist (long ptr);
	private static native String getAlbum  (long ptr);
	private static native String getComment(long ptr);
	private static native String getGenre  (long ptr);
	private static native long   getYear   (long ptr);
	private static native long   getTrack  (long ptr);

	private static native void setTitle  (long ptr, String title);
	private static native void setArtist (long ptr, String artist);
	private static native void setAlbum  (long ptr, String album);
	private static native void setComment(long ptr, String comment);
	private static native void setGenre  (long ptr, String genre);
	private static native void setYear   (long ptr, long   year);
	private static native void setTrack  (long ptr, long   track);
	
	private static native boolean isEmpty(long ptr);
	
	public String getTitle  () { return getTitle(ptr); }
	public String getArtist () { return getArtist(ptr); }
	public String getAlbum  () { return getAlbum(ptr); }
	public String getComment() { return getComment(ptr); }
	public String getGenre  () { return getGenre(ptr); }
	public long   getYear   () { return getYear(ptr); }
	public long   getTrack  () { return getTrack(ptr); }

	public void setTitle  (String title)   { setTitle(ptr, title); }
	public void setArtist (String artist)  { setArtist(ptr, artist); }
	public void setAlbum  (String album)   { setAlbum(ptr, album); }
	public void setComment(String comment) { setComment(ptr, comment); }
	public void setGenre  (String genre)   { setGenre(ptr, genre); }
	public void setYear   (int    year)    { setYear(ptr, year); }
	public void setTrack  (int    track)   { setTrack(ptr, track); }
	
	public boolean isEmpty() { return isEmpty(ptr); }
	
	public static void duplicate(Tag source, Tag target) {
		duplicate(source, target, true);
	}
	
	public static void duplicate(
			Tag source, Tag target, boolean overwrite) {
		duplicate(source.ptr, target.ptr, overwrite);
	}

	private static native void duplicate(
			long source, long target, boolean overwrite);
}
