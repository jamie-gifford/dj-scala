package org.kde.taglib.wavpack;

import org.kde.taglib.AudioProperties;
import org.kde.taglib.FileRef;

public class Properties extends AudioProperties {
	public Properties(FileRef ref, long ptr) {
		super(ref, ptr);
	}

	public int getBitsPerSample() { return getBitsPerSample(ptr); }
	public int getVersion()       { return getVersion(ptr); }

	private static native int getBitsPerSample(long ptr);
	private static native int getVersion(long ptr);
}
