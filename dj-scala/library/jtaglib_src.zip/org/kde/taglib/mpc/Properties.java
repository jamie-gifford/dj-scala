package org.kde.taglib.mpc;

import org.kde.taglib.AudioProperties;
import org.kde.taglib.FileRef;

public class Properties extends AudioProperties {
	public Properties(FileRef ref, long ptr) {
		super(ref, ptr);
	}
	
	public int getMpcVersion() {
		return getMpcVersion(ptr);
	}

	private static native int getMpcVersion(long ptr);
}
