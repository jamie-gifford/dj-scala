package org.kde.taglib.trueaudio;

import org.kde.taglib.AudioProperties;
import org.kde.taglib.FileRef;

public class Properties extends AudioProperties {
	public Properties(FileRef ref, long ptr) {
		super(ref, ptr);
	}
	
	public int getBitsPerSample() { return getBitsPerSample(ptr); }
	public int getTtaVersion()    { return getTtaVersion(ptr); }

	private static native int getBitsPerSample(long ptr);
	private static native int getTtaVersion(long ptr);
}
