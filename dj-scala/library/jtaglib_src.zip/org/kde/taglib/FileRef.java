package org.kde.taglib;

import java.io.File;
import java.net.URISyntaxException;
import java.net.URL;

public class FileRef {
	public static final String[] defaultFileExtensions;
	
	private final long ptr;
	
	private Tag             tag             = null;
	private AudioProperties audioProperties = null;
	
	static {
		URL url = FileRef.class.getProtectionDomain()
			.getCodeSource().getLocation();
		
		File file;
		
		try {
			file = new File(url.toURI());
		} catch (URISyntaxException e) {
			throw new IllegalArgumentException(url.toString(), e);
		}
		
		String osname = System.getProperty("os.name");
		String libname;
		
		if (osname.startsWith("Windows")) {
			libname = "java-taglib.dll";
		}
		else if ("Mac OS X".equals(osname)) {
			libname = "libjava-taglib.dynlib";
		}
		else if ("Linux".equals(osname)) {
			libname = "libjava-taglib.so";
		}
		else {
			throw new IllegalArgumentException(
					"operating system not supported: " + osname);
		}
		
		System.load(file.getParent() + File.separatorChar + libname);
		
		defaultFileExtensions = defaultFileExtensions();
	}
	
	public FileRef() {
		ptr = init0();
		
		if (ptr == 0) {
			throw new OutOfMemoryError();
		}
	}
	
	public FileRef(FileRef ref) {
		ptr = init1(ref.ptr);

		if (ptr == 0) {
			throw new OutOfMemoryError();
		}
	}

	public FileRef(String fileName) {
		this(fileName, true, AudioProperties.ReadStyle.Average);
	}

	public FileRef(String fileName, boolean readAudioProperties) {
		this(fileName, readAudioProperties,
				AudioProperties.ReadStyle.Average);
	}
	
	public FileRef(String fileName, boolean readAudioProperties,
			AudioProperties.ReadStyle audioPropertiesStyle) {
		ptr = init2(fileName, readAudioProperties, audioPropertiesStyle.style);

		if (ptr == 0) {
			throw new OutOfMemoryError();
		}
	}
	
	private static native long init0();
	private static native long init1(long ptr);
	private static native long init2(String fileName,
			boolean readAudioProperties,
			int audioPropertiesStyle);
	
	public Tag getTag() { 
		if (tag == null) {
			tag = getTag(ptr);
		}
		return tag;
	}
	
	public AudioProperties getAudioProperties() {
		if (audioProperties == null) {
			audioProperties = getAudioProperties(ptr);
		}
		return audioProperties;
	}
	
	public boolean save() {
		return save(ptr);
	}
	
	public boolean isNull() {
		return isNull(ptr);
	}
	
	@Override
	public boolean equals(Object other) {
		if (other == null || !(other instanceof FileRef)) {
			return false;
		}
		else {
			return equals(ptr, ((FileRef) other).ptr);
		}
	}

	private native AudioProperties getAudioProperties(long ptr);
	private native Tag             getTag(long ptr);
	
	private static native boolean save(long ptr);
	private static native boolean isNull(long ptr);
	private static native boolean equals(long ptr, long other);
	private static native void    delete(long ptr);
	
	@Override
	protected void finalize() throws Throwable {
		delete(ptr);
	}
	
	private static native String[] defaultFileExtensions();
}
