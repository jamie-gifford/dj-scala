package org.kde.taglib;

public class AudioProperties {
	public enum	ReadStyle {
		Fast(0),
		Average(1),
		Accurate(2);
				
		public final int style;
		
		ReadStyle(int style) {
			this.style = style;
		}
	}
	
	final protected long ptr;
	
	/** Because the AudioProperties will be deleted when the FileRef
	 *  gets deleted we need this to keep the FileRef alive.
	 */
	@SuppressWarnings("unused")
	final private FileRef ref;
	
	protected AudioProperties(FileRef ref, long ptr) {
		this.ref = ref;
		this.ptr = ptr;
	}
	
	public int getLength()     { return getLength(ptr); }
	public int getBitrate()    { return getBitrate(ptr); }
	public int getSampleRate() { return getSampleRate(ptr); }
	public int getChannels()   { return getChannels(ptr); }

	native static private int getLength(long ptr);
	native static private int getBitrate(long ptr);
	native static private int getSampleRate(long ptr);
	native static private int getChannels(long ptr);
}
