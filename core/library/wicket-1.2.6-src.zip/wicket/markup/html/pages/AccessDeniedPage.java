/*
 * $Id: AccessDeniedPage.java 459117 2006-02-09 13:16:04Z jcompagner $
 * $Revision: 459117 $ $Date: 2006-02-09 14:16:04 +0100 (Thu, 09 Feb 2006) $
 *
 * ==============================================================================
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package wicket.markup.html.pages;

import javax.servlet.http.HttpServletResponse;

import wicket.markup.html.WebPage;

/**
 * Page expired error page.
 *
 * @author Jonathan Locke
 */
public class AccessDeniedPage extends WebPage
{
	private static final long serialVersionUID = 1L;

	/**
	 * Constructor.
	 */
	public AccessDeniedPage()
	{
		add(homePageLink("homePageLink"));
	}

	/**
	 * @see wicket.markup.html.WebPage#configureResponse()
	 */
	protected void configureResponse()
	{
		super.configureResponse();
		getWebRequestCycle().getWebResponse().getHttpServletResponse().setStatus(HttpServletResponse.SC_FORBIDDEN);
	}
	/**
	 * @see wicket.Component#isVersioned()
	 */
	public boolean isVersioned()
	{
		return false;
	}

	/**
	 * @see wicket.Page#isErrorPage()
	 */
	public boolean isErrorPage()
	{
		return true;
	}
}