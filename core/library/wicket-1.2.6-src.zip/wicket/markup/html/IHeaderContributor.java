/*
 * $Id: IHeaderContributor.java 459910 2006-03-20 10:11:34Z jcompagner $
 * $Revision: 459910 $ $Date: 2006-03-20 11:11:34 +0100 (Mon, 20 Mar 2006) $
 * 
 * ==============================================================================
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package wicket.markup.html;

import java.io.Serializable;

import wicket.Response;

/**
 * An interface to be implemented by components which are able to render the
 * header section associated with the markup. Default implementations are with
 * WebComponent and WebMarkupContainer.
 * 
 * @author Juergen Donnerstag
 */
public interface IHeaderContributor extends Serializable
{
	/**
	 * Render to the web response whatever the component wants to contribute to
	 * the head section.
	 * <p>
	 * Note: This method is kind of dangerous as users are able to write to the
	 * output whatever they like.
	 * 
	 * @param response
	 *            Response object
	 */
	void renderHead(final Response response);
}
